package com.example.caps_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapsProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapsProjectApplication.class, args);
		System.out.println("welcome to my Capstone project");

	}

}

